export const user={
    name:"Никита",
    secondName:"Мутовин",
    mail:"n-mutovin2003@mail.ru"
}
export const cards = [
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },

     {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    }, {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    },
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    }
    
];
export const  savedCard=[
    {
        name: "33 слова о дизайне",
        photo:
            "https://sun9-63.userapi.com/impg/yb3Tlw3SWrGnMmRRVYDfdtJzq1aqlVtORuKfrQ/HYsCBmqCsSA.jpg?size=960x1280&quality=96&sign=e4a2c8c3048048c312459b2b1e0dfd08&type=album",
        time: "1ч33 минуты",
    }
]