Frontend http://react-movies-app.nomoredomainsrocks.ru
Ссылка на макет - https://www.figma.com/file/6FMWkB94wE7KTkcCgUXtnC/light-1?type=design&node-id=891-3857&mode=design&t=2o1n0jVrlmCiWxAF-0    light-3
Ссылка на пулл реквест - https://github.com/nUc1eaAr-gampRUS545/movies-explorer-frontend/pull/3